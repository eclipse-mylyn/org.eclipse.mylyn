
public class test {
	
	
	public static void main(String[] args) {
		
		
		
		int halloWelt = 1;
		System.out.println("yo");
		halloWelt++;
		
	}
	
	private static void foo() {
		
	}
}